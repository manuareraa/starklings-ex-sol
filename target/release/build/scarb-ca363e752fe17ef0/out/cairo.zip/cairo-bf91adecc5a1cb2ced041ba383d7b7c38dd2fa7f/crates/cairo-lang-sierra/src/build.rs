use lalrpop::process_root;

fn main() {
    process_root().unwrap();
}
